---
tags:
  - project-plan
  - fullstack
  - gamification
  - nextjs
  - supabase
  - portfolio-case-study
date: 2026-08-26
status: planning
project_name: "Drill & Drop"
---

# 🎵 Project Plan: "Drill & Drop" (Gamified Rehearsal Tracker)

## 1. Project Overview & Vision
**"Drill & Drop"** is a gamified web application designed to track marching band attendance, practice hours, and section goals. By wrapping mundane administrative tasks in the engaging UI/UX of a "Gacha/Battle Pass" game (inspired by *Blue Archive* and *Genshin Impact*), the app transforms rehearsal compliance into an addictive, rewarding experience for band members.

> [!abstract] Core Philosophy
> "Don't just track attendance; make showing up feel like an achievement."

## 2. Problem Statement & Solution
### The Problem
Marching bands struggle with consistent attendance, member engagement during repetitive drills, and the administrative burden of tracking practice hours manually. Traditional spreadsheets or basic apps lack the psychological hooks to motivate teenagers/young adults.

### The Solution
Apply **Gacha Game Psychology** to real-world community engagement. By framing practices as "Daily Commissions" and attendance as "Battle Pass XP", we leverage variable rewards, visual progression, and social competition to drive intrinsic and extrinsic motivation.

## 3. Target Audience & Stakeholders
*   **Primary Users (Band Members):** Need a frictionless, visually appealing way to check in, view their "stats," and earn rewards.
*   **Admin (Band Director/Drum Majors):** Need a quick way to assign "Quests" (e.g., "Perfect the 8-to-5 step"), log attendance, and manage the reward economy.

## 4. Weekend MVP Scope
> [!warning] Scope Control
> To ensure completion over a single weekend, we are strictly limiting the MVP to the core gamification loop. 

### In Scope (MVP)
1.  **Authentication:** Secure login for members and admins.
2.  **Admin Dashboard ("The Mission Board"):** Create and assign daily/weekly quests. Log member attendance.
3.  **User Dashboard ("Daily Commissions"):** View active quests, check off completed practices, and view personal XP/Level progress.
4.  **Leaderboard ("Hall of Fame"):** Real-time ranking of members by XP and "Pull Tickets" earned.
5.  **Gacha UI Elements:** Anime-inspired UI, progress bars, and simple "pull/reward" animations.

### Out of Scope (Post-MVP)
*   Actual gacha pulling mechanics (MVP uses direct point redemption).
*   Complex scheduling/calendar integrations.
*   Push notifications (will rely on email or manual checks for MVP).
*   Payment processing for premium tiers.

## 5. Technical Architecture & Stack
*   **Frontend:** Next.js (App Router), TypeScript, Tailwind CSS.
    *   *UI Library/Style:* Custom Tailwind config with anime/gacha aesthetics (glassmorphism, vibrant accent colors, sharp borders). Framer Motion for micro-interactions (e.g., XP bar filling up).
*   **Backend & Database:** Supabase.
    *   *Auth:* Supabase Auth (Email/Password or Magic Links).
    *   *Database:* PostgreSQL (Relational data for users, quests, and progress).
    *   *API:* Supabase REST API with Row Level Security (RLS) for data protection.
*   **Hosting:** Vercel (Frontend) + Supabase Cloud (Backend).

## 6. High-Level Database Schema
*   **`profiles`**: `id` (uuid), `role` (admin/member), `display_name`, `section`, `total_xp`, `pull_tickets`, `level`.
*   **`quests`**: `id`, `title`, `description`, `xp_reward`, `ticket_reward`, `quest_type` (daily/weekly/admin), `is_active`, `created_at`.
*   **`quest_progress`**: `id`, `user_id`, `quest_id`, `status` (pending/completed), `completed_at`.
*   **`attendance_logs`**: `id`, `user_id`, `date`, `hours_logged`, `xp_earned`.

## 7. Gamification & Psychology Mechanics
> [!note] Portfolio Case Study Highlight
> This section is crucial for the blog post. It proves you understand *why* games work, not just how to code them.

1.  **The Zeigarnik Effect (Incomplete Tasks):** Daily commissions create a psychological itch. Members want to "clear their board" before the day ends.
2.  **Visual Progression & The "Ding":** Seeing an XP bar fill up and a level-up animation provides immediate dopamine hits for mundane tasks like showing up on time.
3.  **Social Proof & Competition:** The leaderboard taps into section rivalries (e.g., Brass vs. Woodwinds) to drive organic engagement.
4.  **Tangible-to-Digital Loop:** Earning "Pull Tickets" that translate to *real-life* rewards (choosing the warm-up song, getting a snack) bridges the digital gap, proving the app's real-world value.

## 8. Portfolio & Case Study Narrative
**Title Idea:** *How I Used Gacha Game Psychology to Improve Real-World Community Engagement.*
**Key Takeaways for Readers:**
*   **Product Thinking:** How I identified a real-world pain point (band attendance) and applied a proven digital framework (gacha battle passes) to solve it.
*   **Full-Stack Execution:** Demonstrating rapid prototyping using Next.js and Supabase to ship a functional MVP in 48 hours.
*   **UX/UI Design:** Translating complex data (attendance, XP) into an engaging, anime-inspired interface that users *want* to open.
*   **Community Impact:** Open-sourcing the tool to help other underfunded school bands in Cebu and the Philippines.

## 9. Success Metrics (MVP)
*   **Technical:** App is deployed, auth works, database RLS is secure, and the core loop (Admin creates quest -> User completes quest -> XP updates -> Leaderboard reflects change) functions without critical bugs.
*   **Product:** The UI successfully conveys the "gacha" aesthetic without sacrificing usability.
*   **Time:** Completed within the 48-hour weekend window.

---
**Next Steps:** 
- [ ] Finalize Execution Plan (Weekend Timeline)
- [ ] Setup Next.js & Supabase repositories
- [ ] Design basic UI wireframes (Figma/Excalidraw)